// ===== Biến toàn cục của game =====
let exp = 0; // Điểm kinh nghiệm hiện tại
let cap = 0; // Chỉ số cấp độ/cảnh giới hiện tại (dùng làm index cho mảng canhGioiList)
let autoTrainInterval = null; // Biến để lưu trữ ID của setInterval cho tu luyện tự động
let playerName = "Vô Danh Tiểu Tốt"; // Tên nhân vật mặc định
let isMusicPlaying = false; // Trạng thái nhạc nền

const expPerClick = 10; // Số EXP tăng mỗi lần tu luyện thủ công
const autoTrainExpRate = 1; // Số EXP tự động tăng mỗi giây
const autoTrainIntervalTime = 1000; // Thời gian tu luyện tự động (miligiay)

// Cấu hình HP và MP ban đầu và tăng theo cấp
const baseHP = 100;
const hpPerCap = 200;
const baseMP = 100;
const mpPerCap = 100;

const canhGioiList = [
  "Phàm Nhân", "Luyện Khí", "Trúc Cơ", "Kim Đan",
  "Nguyên Anh", "Hóa Thần", "Luyện Hư", "Hợp Thể",
  "Đại Thừa", "Độ Kiếp", "Phi Thăng", "Chân Tiên",
  "Huyền Tiên", "Địa Tiên", "Thiên Tiên", "Kim Tiên",
  "Đại La Kim Tiên", "Tiên Vương", "Tiên Đế", "Tiên Tôn",
  "Bán Thánh", "Chân Thánh", "Thánh Nhân", "Đạo Tổ", "Vô Thượng Đạo Tổ"
];

const canhGioiEXP = [
  100, 200, 400, 800, 1600, 3200, 6400, 12800,
  25600, 51200, 99999, 150000, 300000, 600000,
  1200000, 2400000, 4800000, 9600000, 15000000,
  30000000, 60000000, 100000000, 200000000,
  500000000, 999999999
];

// ===== Các đoạn hội thoại và cốt truyện (Thêm lời thoại cho các cảnh giới còn thiếu) =====
const dialogues = {
    "startGame": "Trong cõi phàm trần này, thế sự nhiễu loạn, danh lợi phù du. Ngươi, một phàm nhân mỏi mệt với bụi trần, bỗng một ngày nhận ra Đại Đạo vô biên đang chờ đợi. Hãy bắt đầu hành trình tu tiên của mình ngay bây giờ, dù chỉ trong những phút giây nhàn rỗi.",

    "Phàm Nhân": { npc: "Mới chỉ là phàm nhân, đừng vội nản chí. Cội nguồn của mọi sức mạnh đều bắt đầu từ đây.", player: "Ta sẽ cố gắng hết sức!", npc2: "Đường tu tiên vô tận, chỉ cần kiên trì, ắt sẽ thành công." },
    "Luyện Khí": { npc: "Kẻ phàm trần kia, ngươi đã cảm nhận được linh khí trời đất rồi sao? Không tệ, bước đầu tiên của vạn kiếp phàm trần đã mở ra.", player: "Người là ai? Sao lại xuất hiện ở đây?", npc2: "Ta là kẻ dẫn lối, là ánh sáng trong đêm tối của con đường tu tiên. Hãy tiếp tục đi, hành trình này còn dài lắm!" },
    "Trúc Cơ": { npc: "Căn cơ đã vững. Ngươi đã thoát khỏi xiềng xích phàm nhân, nhưng hãy nhớ, càng lên cao càng hiểm nguy.", player: "Ta đã thấy được con đường. Cảm ơn người tiền bối.", npc2: "Đừng vội mừng, đây mới chỉ là khởi đầu. Ngươi còn nhiều điều phải học hỏi, nhiều cảnh giới phải chinh phục." },
    "Kim Đan": { npc: "Kim Đan ngưng tụ! Ngươi đã một bước thành tiên, thoát thai hoán cốt. Thân thể đã được tẩy luyện, nhưng tâm hồn thì sao?", player: "Kim Đan... ta đã thành tiên sao?", npc2: "Tiên thì có nhiều loại. Ngươi mới chỉ là Kim Đan, còn cả một Tiên giới rộng lớn phía trước. Đừng ngủ quên trên chiến thắng." },
    "Nguyên Anh": { npc: "Nguyên Anh xuất khiếu, thần hồn phiêu dật. Ngươi đã có thể du hành thiên hạ bằng thần thức. Giữ vững tâm trí, chớ để tâm ma quấy nhiễu.", player: "Cảm giác này thật kỳ diệu! Ta có thể nhìn thấy vạn vật từ trên cao.", npc2: "Thế giới này rộng lớn hơn ngươi tưởng. Sức mạnh đi kèm với trách nhiệm. Hãy dùng nó để bảo vệ lẽ phải, không phải để hủy diệt." },
    "Hóa Thần": { npc: "Ngươi đã Hóa Thần, gần như vô địch ở hạ giới. Sức mạnh của ngươi đủ để thay đổi càn khôn. Hãy chuẩn bị cho kiếp nạn sắp tới.", player: "Kiếp nạn? Chẳng lẽ là...", npc2: "Đúng vậy, Lôi Kiếp Thiên Phạt. Chỉ kẻ mạnh nhất mới có thể vượt qua, phi thăng Tiên giới." },
    "Luyện Hư": { npc: "Thân thể hư hóa, hòa mình vào hư không. Ngươi gần như vô hình vô tướng, đã không còn bị ràng buộc bởi vật chất. Một cảnh giới đáng để ngưỡng mộ!", player: "Ta cảm thấy mình hòa vào vạn vật...", npc2: "Đúng vậy. Ngươi đã chạm tới một phần của Đại Đạo. Hãy trân trọng cảnh giới này." },
    "Hợp Thể": { npc: "Hợp nhất với thiên địa, đại đạo cận kề. Ngươi là một thể với vũ trụ, cảm nhận được sự bao la vô tận. Ngươi sắp hoàn thành hành trình phàm trần rồi.", player: "Ta cảm thấy sức mạnh vô tận!", npc2: "Đó là sức mạnh của sự hợp nhất. Chuẩn bị cho Đại Thừa, đó sẽ là đỉnh cao trước khi Độ Kiếp." },
    "Đại Thừa": { npc: "Đại đạo viên mãn, sắp sửa độ kiếp. Ngươi đã đạt đến đỉnh cao của tu luyện ở hạ giới, chỉ còn chờ một bước để siêu phàm. Thời cơ đã chín muồi!", player: "Kiếp nạn cuối cùng... Ta đã sẵn sàng!", npc2: "Tâm thế vững vàng là chìa khóa. Hãy đối mặt với nó!" },
    "Độ Kiếp": { npc: "Lôi kiếp đã đến! Hãy tập trung toàn bộ tinh thần và sức mạnh. Đây là khoảnh khắc quyết định vận mệnh của ngươi!", player: "Kiếp này ta phải vượt qua!", npc2: "Vận mệnh nằm trong tay ngươi. Chúc ngươi may mắn." },
    "Phi Thăng": { npc: "Ngươi đã thành công Phi Thăng! Tiên giới rộng lớn, đầy rẫy cơ duyên và thử thách. Hãy tiếp tục hành trình của mình, và tìm kiếm Đại Đạo tối thượng.", player: "Tiên giới... Ta đã đến rồi!", npc2: "Hành trình mới đã bắt đầu. Ngươi sẽ gặp nhiều Tiên nhân mạnh mẽ hơn, nhiều bí mật cổ xưa hơn." },
    "Chân Tiên": { npc: "Bước vào cảnh giới Chân Tiên, ngươi cảm nhận được sức mạnh tiên khí. Tiên giới rộng lớn, vô vàn cơ duyên đang chờ đón.", player: "Tiên khí thật dồi dào!", npc2: "Hãy hấp thụ nó, và củng cố căn cơ Tiên nhân của ngươi." },
    "Huyền Tiên": { npc: "Sức mạnh Huyền Tiên giúp ngươi du ngoạn khắp Tiên giới, hiểu rõ hơn về thiên cơ và định luật.", player: "Thế giới này thật rộng lớn!", npc2: "Còn rất nhiều điều để khám phá. Ngươi mới chỉ bắt đầu mà thôi." },
    "Địa Tiên": { npc: "Địa Tiên đại năng, có thể kiến tạo tiểu thế giới. Ngươi đã có thể ảnh hưởng đến một vùng trời đất.", player: "Một vùng trời đất nằm trong tay ta sao?", npc2: "Đúng vậy. Ngươi có thể định hình nó theo ý muốn của mình." },
    "Thiên Tiên": { npc: "Thiên Tiên vô song, đã nắm giữ một phần thiên đạo. Uy danh của ngươi vang vọng khắp các Tiên Vực.", player: "Ta cảm nhận được Thiên Đạo!", npc2: "Đó là dấu hiệu của sự vĩ đại. Hãy dùng nó khôn ngoan." },
    "Kim Tiên": { npc: "Kim Tiên bất diệt, đã đạt đến cảnh giới phi phàm. Ngươi đã đứng vào hàng ngũ những người mạnh nhất Tiên giới.", player: "Không ai có thể sánh bằng ta!", npc2: "Chớ kiêu ngạo. Kẻ mạnh hơn ngươi vẫn còn." },
    "Đại La Kim Tiên": { npc: "Đại La Kim Tiên, một bước lên trời. Ngươi đã có thể nhìn thấu vạn vật, không gì có thể che mắt.", player: "Ta thấy được chân lý!", npc2: "Chân lý đôi khi rất nghiệt ngã. Chuẩn bị cho những cảnh giới cao hơn." },
    "Tiên Vương": { npc: "Phong hào Tiên Vương! Ngươi là bá chủ một phương, hiệu lệnh thiên hạ, vạn Tiên phải cúi đầu.", player: "Ta là Tiên Vương!", npc2: "Quyền lực đi đôi với trách nhiệm. Ngươi có sẵn lòng gánh vác nó không?" },
    "Tiên Đế": { npc: "Tiên Đế vô địch! Cửu Thiên Thập Địa phải run sợ trước uy thế của ngươi. Mọi quy luật đều nằm trong tay.", player: "Ta là chủ宰 của Tiên giới!", npc2: "Ngươi đã đạt đến đỉnh cao. Nhưng liệu có còn gì ngoài đỉnh cao đó?" },
    "Tiên Tôn": { npc: "Tiên Tôn chí cao! Vạn pháp quy tông, không ai sánh bằng. Ngươi đã vượt lên trên cả Tiên Đế. Ngươi đã có thể tạo ra Đại Đạo của riêng mình.", player: "Ta là Tiên Tôn!", npc2: "Ngươi đã tiến vào cảnh giới của sự sáng tạo. Vạn vật sẽ nghe theo lời ngươi." },
    "Bán Thánh": { npc: "Tiến vào Bán Thánh! Một chân đã bước vào cảnh giới Thánh nhân. Ngươi có thể cảm nhận được Đại Đạo nguyên thủy.", player: "Ta cảm nhận được sự khởi nguồn!", npc2: "Đó là sự rung động của Đại Đạo. Ngươi đã rất gần rồi." },
    "Chân Thánh": { npc: "Chân Thánh vô lượng! Ngươi đã vượt khỏi Tam Giới, không còn bị luật lệ trói buộc. Một ý niệm có thể hủy diệt tinh hà.", player: "Ta không còn bị trói buộc!", npc2: "Ngươi đã là một thực thể siêu thoát. Ngươi là Đạo trong Đạo." },
    "Thánh Nhân": { npc: "Thánh Nhân bất tử! Vĩnh hằng bất diệt. Ngươi là hiện thân của Đại Đạo, không gì có thể lay chuyển. Ngươi đã bất tử!", player: "Ta đã là Thánh Nhân!", npc2: "Bất tử không có nghĩa là không còn gì để học. Hãy nhìn sâu vào Đạo." },
    "Đạo Tổ": { npc: "Đạo Tổ siêu thoát! Vạn vật do ngươi sinh ra, vạn pháp do ngươi quy định. Ngươi là khởi nguồn của mọi thứ. Ngươi đã vượt qua mọi giới hạn!", player: "Ta là Đạo Tổ!", npc2: "Ngươi đã trở thành một phần của vĩnh hằng. Không gì có thể lay chuyển ngươi." },
    "Vô Thượng Đạo Tổ": { npc: "Vô Thượng Đạo Tổ! Ngươi đã hoàn thành hành trình. Không còn gì có thể trói buộc ngươi. Mọi quy luật, mọi khái niệm đều nằm dưới chân ngươi. Ta không còn gì để dạy ngươi nữa.", player: "Đại Đạo... ta đã nắm giữ nó rồi sao?", npc2: "Ngươi đã vượt lên trên mọi khái niệm về sinh tử, thời gian, không gian. Ngươi chính là Đạo. Chúc mừng, Đạo Tổ!" }
};


// ===== Hàm khởi tạo và chạy game =====

function startGame() {
  document.getElementById("startScreen").style.display = "none";
  document.getElementById("gameScreen").style.display = "block";
  loadGame(); // Tải dữ liệu game nếu có
  updateUI(); // Cập nhật hiển thị UI ban đầu
  
  // Tự động play nhạc khi vào game (trình duyệt có thể chặn nếu không có tương tác người dùng)
  playMusic();
  // Hiển thị cốt truyện mở đầu sau khi vào game
  showStoryPopup(dialogues.startGame);
}

// ===== Hàm logic game =====

function train() {
  exp += expPerClick;
  checkLevelUp();
  updateUI();
}

function autoTrain() {
    exp += autoTrainExpRate;
    checkLevelUp();
    updateUI();
    saveGame();
}

function toggleAutoTrain() {
    const autoTrainBtn = document.getElementById("autoTrainBtn");
    if (autoTrainInterval) {
        clearInterval(autoTrainInterval);
        autoTrainInterval = null;
        autoTrainBtn.innerText = "Tu luyện tự động";
        autoTrainBtn.classList.remove("auto-train-active");
    } else {
        autoTrainInterval = setInterval(autoTrain, autoTrainIntervalTime);
        autoTrainBtn.innerText = "Dừng tu luyện tự động";
        autoTrainBtn.classList.add("auto-train-active");
        saveGame();
    }
}

// Hàm kiểm tra và xử lý đột phá cảnh giới (Đã điều chỉnh để hiển thị NPC Dialogue)
function checkLevelUp() {
  let maxExpForCurrentCap = canhGioiEXP[cap];

  // Logic đột phá: Nếu EXP đủ, trừ EXP và tăng cấp
  if (exp >= maxExpForCurrentCap) {
    exp -= maxExpForCurrentCap;
    cap++;

    // Đảm bảo cấp độ không vượt quá giới hạn của mảng canhGioiList
    if (cap >= canhGioiList.length) {
      cap = canhGioiList.length - 1; // Giữ ở cảnh giới cao nhất
      exp = canhGioiEXP[cap]; // Đặt EXP bằng max để tránh hiển thị số âm hoặc tiến trình sai
      if (autoTrainInterval) { // Dừng tự động tu luyện nếu đã đạt max
        toggleAutoTrain(); // Gọi lại để tắt auto-train
      }
      showNpcDialogue(dialogues["Vô Thượng Đạo Tổ"]); // Luôn hiển thị đối thoại cuối cùng
      
    } else {
      // Hiển thị đối thoại của NPC cho cảnh giới mới
      const currentCanhGioiName = canhGioiList[cap];
      if (dialogues[currentCanhGioiName]) { // Kiểm tra xem có lời thoại cho cảnh giới này không
          showNpcDialogue(dialogues[currentCanhGioiName]);
      } else {
          // Nếu không có lời thoại đặc biệt, hiển thị alert mặc định
          alert("💥 Đột phá cảnh giới: " + currentCanhGioiName);
      }
    }
  }
}

// Hàm tính toán HP và MP dựa trên cảnh giới
function calculateStats() {
    const currentHP = baseHP + (cap * hpPerCap);
    const currentMP = baseMP + (cap * mpPerCap);
    return { hp: currentHP, mp: currentMP };
}

// ===== Hàm cập nhật giao diện người dùng (UI) =====

function updateUI() {
  const canhGioiElement = document.getElementById("canhGioi");
  const expTextElement = document.getElementById("expText");
  const expProgressBar = document.getElementById("expProgressBar");

  // Cập nhật thông tin trong bảng hiển thị chính
  canhGioiElement.innerText = canhGioiList[cap];

  let currentMaxExp = canhGioiEXP[cap];

  if (cap === canhGioiList.length - 1 && exp >= currentMaxExp) {
    expTextElement.innerText = "Đã Phi Thăng!";
    expProgressBar.style.width = "100%";
  } else {
    expTextElement.innerText = `${exp}/${currentMaxExp}`;
    const progressPercent = (exp / currentMaxExp) * 100;
    expProgressBar.style.width = `${progressPercent}%`;
  }

  // Cập nhật thông tin trong popup thông tin nhân vật (nếu đang mở)
  const infoCanhGioi = document.getElementById("infoCanhGioi");
  const infoHP = document.getElementById("infoHP");
  const infoMP = document.getElementById("infoMP");
  const playerNameInput = document.getElementById("playerNameInput");

  if (infoCanhGioi) infoCanhGioi.innerText = canhGioiList[cap];
  
  const stats = calculateStats();
  if (infoHP) infoHP.innerText = stats.hp;
  if (infoMP) infoMP.innerText = stats.mp;

  // Cập nhật tên người chơi trong input khi tải game/cập nhật
  if (playerNameInput) {
      playerNameInput.value = playerName;
  }
}

// ===== Hàm hiển thị và đóng popup =====

function showStoryPopup(text) {
    document.getElementById("storyText").innerText = text;
    document.getElementById("storyPopup").style.display = "flex";
}

function closeStoryPopup() {
    document.getElementById("storyPopup").style.display = "none";
}

function showNpcDialogue(dialogueObject) {
    const npcDialogueTextElement = document.getElementById("npcDialogueText");
    const npcDialoguePopup = document.getElementById("npcDialoguePopup");

    let dialogueString = "";
    // Nối các đoạn hội thoại lại
    if (dialogueObject.npc) {
        dialogueString += `Người Bí Ẩn: "${dialogueObject.npc}"\n\n`;
    }
    if (dialogueObject.player) {
        dialogueString += `Ngươi: "${dialogueObject.player}"\n\n`;
    }
    if (dialogueObject.npc2) { // Nếu có đoạn hội thoại thứ 2 của NPC
        dialogueString += `Người Bí Ẩn: "${dialogueObject.npc2}"`;
    }

    npcDialogueTextElement.innerText = dialogueString.trim();
    npcDialoguePopup.style.display = "flex";
}

function closeNpcDialogue() {
    document.getElementById("npcDialoguePopup").style.display = "none";
}

// Hàm hiển thị bảng thông tin nhân vật
function showCharacterInfo() {
    document.getElementById("characterInfoPopup").style.display = "flex";
    document.getElementById("playerNameInput").value = playerName;
    updateUI(); // Cập nhật các chỉ số khi mở bảng để đảm bảo luôn mới nhất
}

// Hàm đóng bảng thông tin nhân vật
function closeCharacterInfo() {
    document.getElementById("characterInfoPopup").style.display = "none";
}

// Hàm lưu tên nhân vật
function savePlayerName() {
    const inputName = document.getElementById("playerNameInput").value;
    if (inputName && inputName.trim() !== "") {
        playerName = inputName.trim();
        alert("Tên nhân vật đã được lưu: " + playerName);
        saveGame(); // Lưu game sau khi đổi tên
    } else {
        alert("Tên nhân vật không được để trống!");
    }
}

// Hàm hiển thị popup "Coming Soon" cho chức năng chiến đấu
function showCombatComingSoon() {
    document.getElementById("combatComingSoonPopup").style.display = "flex";
}

// Hàm đóng popup "Coming Soon"
function closeCombatComingSoon() {
    document.getElementById("combatComingSoonPopup").style.display = "none";
}

// ===== Hàm điều khiển nhạc nền =====
const backgroundMusic = document.getElementById("backgroundMusic");
const musicToggleButton = document.querySelector(".music-toggle-btn");

function playMusic() {
    if (backgroundMusic) {
        // Trình duyệt thường yêu cầu tương tác người dùng để phát nhạc tự động
        backgroundMusic.volume = 0.5; // Đặt âm lượng mặc định 50%
        backgroundMusic.play().then(() => {
            isMusicPlaying = true;
            if (musicToggleButton) musicToggleButton.innerText = "🔇 Tắt nhạc";
        }).catch(error => {
            console.log("Tự động phát nhạc bị chặn:", error);
            isMusicPlaying = false; // Đảm bảo trạng thái đúng
            if (musicToggleButton) musicToggleButton.innerText = "🔊 Nhạc nền";
        });
    }
}

function pauseMusic() {
    if (backgroundMusic) {
        backgroundMusic.pause();
        isMusicPlaying = false;
        if (musicToggleButton) musicToggleButton.innerText = "🔊 Nhạc nền";
    }
}

function toggleMusic() {
    if (isMusicPlaying) {
        pauseMusic();
    } else {
        playMusic();
    }
}

// ===== Hàm lưu và tải game =====

function saveGame() {
    const gameData = {
        exp: exp,
        cap: cap,
        autoTrainActive: autoTrainInterval !== null,
        playerName: playerName, // Lưu tên nhân vật
        isMusicPlaying: isMusicPlaying // Lưu trạng thái nhạc
    };
    localStorage.setItem('tuTienNhanRoiData', JSON.stringify(gameData));
    console.log('Game đã được lưu!');
}

function loadGame() {
    const savedData = localStorage.getItem('tuTienNhanRoiData');
    if (savedData) {
        const gameData = JSON.parse(savedData);
        exp = gameData.exp;
        cap = gameData.cap;
        playerName = gameData.playerName || "Vô Danh Tiểu Tốt"; // Tải tên, nếu không có thì mặc định
        
        // Khôi phục trạng thái auto-train
        if (gameData.autoTrainActive) {
            // Tắt trước để tránh setInterval chạy hai lần nếu có lỗi
            if (autoTrainInterval) {
                clearInterval(autoTrainInterval);
                autoTrainInterval = null;
            }
            toggleAutoTrain(); // Kích hoạt lại auto-train
        }

        // Khôi phục trạng thái nhạc
        isMusicPlaying = gameData.isMusicPlaying; // Cập nhật biến trạng thái nhạc
        if (isMusicPlaying) { // Chỉ play nếu trạng thái là đang play
            playMusic();
        } else {
            pauseMusic(); // Đảm bảo nhạc tắt nếu trước đó tắt
        }

        console.log('Game đã được tải!');
    } else {
        console.log('Không tìm thấy dữ liệu game đã lưu.');
    }
    updateUI(); // Cập nhật UI sau khi tải game
}

// Đảm bảo load game khi trang được tải lần đầu
document.addEventListener('DOMContentLoaded', () => {
    // Không gọi loadGame ở đây vì nó đã được gọi trong startGame() để đảm bảo UI đúng sau khi vào game.
    // Nút nhạc sẽ được xử lý trạng thái đúng khi loadGame và updateUI.
});
